const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  paymentId: String,
  orderStatus: String,
  paymentStatus: String,
  totalAmount: Number,
  orderDate: Date,
  orderUpdateDate: Date,
});

module.exports = mongoose.model("Product",UserSchema)