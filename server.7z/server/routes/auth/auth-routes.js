const express = require("express");
const {
  registerUser,
  loginUser,
  logoutUser,
  authMiddleware,
} = require("../../controller/Auth/auth_controller");
const {
  addProduct,
  getAllAdminProduct,
  deleteProduct,
  editProduct
} = require("../../controller/Auth/admin/product_controller");
const router = express.Router();

const app = express();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/logout", logoutUser);
router.get("/check-auth", authMiddleware);
router.post("/add", addProduct);
router.get("/getAllAdminProduct", getAllAdminProduct);
router.delete("/deleteProduct/:id", deleteProduct);
router.put("/editProduct/:id",editProduct);

module.exports = router;
