// const express = require("express");

// const {
//   addProduct,
//   getAllAdminProduct,
// } = require("../../controller/Auth/admin/product_controller");

// const router = express.Router();
// const app = express();

// router.post("/add", addProduct);
// router.get("/getAllAdminProduct", getAllAdminProduct);

// module.exports = router;
