const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const authRouter = require("./routes/auth/auth-routes");
// const adminRouter = require('./routes/admin/admin_routes');

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: "http://localhost:3000",
    methods: ["GET", "POST", "PATCH", "DELETE", "PUT"],
    allowedHeaders:
      "Content-Type,Authorization,X-Requested-With,Expires,Pragma,Cache-Control",
    credentials: true,
  })
);

const PORT = process.env.PORT || 9000;

mongoose
  .connect("mongodb://127.0.0.1:27017/CRUD1")
  .then(() => console.log("MongoDB is connected"))
  .catch((err) => console.log(err));

app.use("/api/auth", authRouter);
// app.use("api/admin",adminRouter)

app.listen(PORT, () => {
  console.log(`Server is started on ${PORT}`);
});
