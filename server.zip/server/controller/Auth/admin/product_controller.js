const ProductSchema = require("../../../model/admin/product");

const addProduct = async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      brand,
      price,
      salePrice,
      totalStock,
      averageReview,
    } = req.body;
    const product = new ProductSchema({
      title,
      description,
      category,
      brand,
      price,
      salePrice,
      totalStock,
      averageReview,
    });
    await product.save();
    res.status(201).json({
      success: true,
      data: product,
    });
  } catch (e) {
    res.status(201).json({
      success: false,
      message: "Error occured",
    });
  }
};

const getAllAdminProduct = async (req, res) => {
  try {
    const allProduct = await ProductSchema.find();
    res.status(200).json({
      success: true,
      data: allProduct,
      message: "Product fetched sucessfully",
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: "Error occured",
    });
  }
};

const editProduct = async (req, res) => {
  try {
    const productId = req.params.id;

    // Check if the product exists
    const product = await ProductSchema.findById(productId);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Update the product
    const updatedProduct = await ProductSchema.findByIdAndUpdate(
      productId,
      req.body,
      { new: true }
    );

    // Return the updated product data
    res
      .status(200)
      .json({ message: "Product updated successfully", data: updatedProduct });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error updating product", error: err.message });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const productId = req.params.id;
    await ProductSchema.findByIdAndDelete(productId); // Assuming you're using MongoDB
    res.status(200).json({ message: "Product deleted successfully" });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error deleting product", error: err.message });
  }
};

module.exports = { addProduct, getAllAdminProduct, deleteProduct, editProduct };
