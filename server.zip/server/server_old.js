const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const user = require("./model/model"); // Assuming you have a model here

const app = express();
app.use(
  cors({
    origin: "http://localhost:2000",
    methods: ["GET", "POST", "PATCH", "DELETE"],
    credentials: true,
  })
);

// Middleware to parse JSON bodies
app.use(express.json());

const PORT = process.env.PORT || 2000;

// MongoDB connection
mongoose
  .connect("mongodb://127.0.0.1:27017/DAY4")
  .then(() => {
    // console.log(mongoose.connection.readyState);
    console.log("Connected to MongoDB");
  })

  .catch((error) => console.error("Could not connect to MongoDB", error));

// Test GET route
app.get("/get", async (req, res) => {
  try {
    const data = await user.find(); // Await the result of the query

    // if (!data || data.length === 0) {
    //   return res.status(404).json({ message: "No users found" });
    // }

    res.status(200).json(data); // Send the fetched data as JSON
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).send("Error fetching data");
  }
});

// Test POST route
app.post("/postUser", async (req, res) => {
  try {
    const { Name, city, Age } = req.body; // Extract the necessary fields from the request body

    // Check if all required fields are present
    if (!Name || !city || !Age) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    // Create a new user document in MongoDB
    const newUser = await user.create({ Name, city, Age });

    // Return success response
    return res
      .status(200)
      .json({ message: "User created successfully", user: newUser });
  } catch (error) {
    console.error("Error creating user:", error);
    return res.status(500).json({ message: "Error in POST request" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is connected on ${PORT}`);
});
